# NodeMailer

NodeMailer is a Simple Node.js Library For Sending Emails with Attachments.

## Installation

Use the package manager [npm](https://www.npmjs.com/package/nodemailer) to install nodemailer.

```bash
npm install nodemailer
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
